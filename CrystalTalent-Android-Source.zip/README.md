# Crystal Talent — Android app

A native Android customer-facing app for Crystal Talent, styled in a formal white, charcoal and champagne-gold palette. It includes a home screen, collection categories, service and company information pages, contact actions, and a quote request form that prepares a message for WhatsApp.

## Build
- Android Gradle Plugin: 8.7.3
- Gradle: 8.9
- JDK: 17
- Compile SDK: 35
- Minimum Android: 6.0 (API 23)

Open this folder in Android Studio and run `app` or use the included GitHub Actions workflow file (provided separately in the delivery bundle) to build a debug APK.

## Quote form behaviour
The form is not connected to a backend and does not save submissions. After required fields are filled, the app opens a WhatsApp message addressed to the business contact shown on the provided Crystal Talent sign. The user must press Send in WhatsApp.

## Notes
- The crown is a scalable vector interpretation of the supplied Crystal Talent crown mark so it remains crisp on different screen sizes.
- Contact details and business location were taken from the supplied shopfront image; verify these details with the business before public release.
