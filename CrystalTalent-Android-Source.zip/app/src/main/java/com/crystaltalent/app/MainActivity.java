package com.crystaltalent.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.TranslateAnimation;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int INK = Color.rgb(32,38,36);
    private static final int GOLD = Color.rgb(184,148,79);
    private static final int GOLD_DARK = Color.rgb(148,114,53);
    private static final int PAPER = Color.rgb(248,247,243);
    private static final int LINE = Color.rgb(232,228,220);
    private static final int MUTED = Color.rgb(110,116,111);
    private static final int WHITE = Color.WHITE;
    private static final String PHONE_NAIM = "9967920717";
    private static final String PHONE_AMAN = "7977061096";
    private FrameLayout pageHost;
    private LinearLayout bottomBar;
    private Page currentPage = new Page("home", null);
    private final ArrayList<Page> history = new ArrayList<>();
    private String preselectedCategory = "";

    private static class Page {
        String type, value;
        Page(String t, String v) { type=t; value=v; }
    }
    private static class Category {
        String title, subtitle, description;
        int icon;
        Category(String t, String s, String d, int i) {title=t;subtitle=s;description=d;icon=i;}
    }
    private final Category[] categories = new Category[] {
        new Category("Trophies & Awards", "Celebrate achievement", "Custom trophy designs for ceremonies, recognition programmes, competitions and milestone celebrations.", R.drawable.ic_trophy),
        new Category("Mementos & Plaques", "Recognition that lasts", "Personalised plaques, commemorative pieces and presentation mementos with carefully finished details.", R.drawable.ic_plaque),
        new Category("Corporate Gifts", "Made for your brand", "Thoughtful gifting for teams, clients, partners, annual functions and special business occasions.", R.drawable.ic_gift),
        new Category("2D / 3D Engraving", "Personalised detailing", "Laser engraving for names, logos, messages and artwork on suitable materials and gift items.", R.drawable.ic_laser),
        new Category("Miniatures & Sculptures", "Distinctive keepsakes", "Custom miniature pieces and sculptural awards created to reflect a concept, symbol or occasion.", R.drawable.ic_sculpture),
        new Category("Custom Awards", "Designed around you", "Share your brief and reference ideas for a tailored award, event piece or one-of-a-kind recognition item.", R.drawable.ic_medal)
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(WHITE);
        getWindow().setNavigationBarColor(WHITE);
        if (android.os.Build.VERSION.SDK_INT >= 26) getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(WHITE);
        pageHost = new FrameLayout(this);
        root.addView(pageHost, new LinearLayout.LayoutParams(-1, 0, 1));
        bottomBar = makeBottomBar();
        root.addView(bottomBar, new LinearLayout.LayoutParams(-1, dp(68)));
        setContentView(root);
        render(currentPage, false);
    }

    private LinearLayout makeBottomBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER);
        bar.setBackground(shape(WHITE, 0, LINE));
        bar.setElevation(dp(12));
        return bar;
    }
    private void updateBottomBar() {
        bottomBar.removeAllViews();
        String selected = currentPage.type;
        if (selected.equals("category") || selected.equals("service") || selected.equals("portfolio") || selected.equals("about")) selected="collection";
        String[] titles={"Home","Collection","Quote","Contact"};
        String[] types={"home","collection","quote","contact"};
        int[] icons={R.drawable.ic_home,R.drawable.ic_grid,R.drawable.ic_quote,R.drawable.ic_phone};
        for (int i=0;i<titles.length;i++) {
            final String type=types[i];
            boolean active=selected.equals(type);
            LinearLayout item=new LinearLayout(this); item.setOrientation(LinearLayout.VERTICAL); item.setGravity(Gravity.CENTER); item.setPadding(dp(4),dp(6),dp(4),dp(4));
            ImageView img=new ImageView(this); img.setImageResource(icons[i]); img.setColorFilter(active?GOLD_DARK:MUTED); item.addView(img,new LinearLayout.LayoutParams(dp(23),dp(23)));
            TextView label=text(titles[i],10,active?GOLD_DARK:MUTED,active?Typeface.BOLD:Typeface.NORMAL); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,-2); lp.topMargin=dp(3); item.addView(label,lp);
            item.setOnClickListener(v->navigateTab(type));
            bottomBar.addView(item,new LinearLayout.LayoutParams(0,-1,1));
        }
    }
    private void navigateTab(String type) { history.clear(); currentPage=new Page(type,null); render(currentPage,true); }
    private void openPage(String type, String value) { history.add(currentPage); currentPage=new Page(type,value); render(currentPage,true); }
    private void render(Page page, boolean animate) {
        View next;
        switch(page.type) {
            case "collection": next=buildCollection(); break;
            case "quote": next=buildQuote(); break;
            case "contact": next=buildContact(); break;
            case "category": next=buildCategory(page.value); break;
            case "about": next=buildAbout(); break;
            case "portfolio": next=buildPortfolio(); break;
            case "service": next=buildService(page.value); break;
            default: next=buildHome(); break;
        }
        pageHost.removeAllViews();
        pageHost.addView(next,new FrameLayout.LayoutParams(-1,-1));
        if (animate) {
            next.setAlpha(0f); next.setTranslationY(dp(10));
            next.animate().alpha(1f).translationY(0).setDuration(240).setInterpolator(new DecelerateInterpolator()).start();
        }
        updateBottomBar();
    }

    private ScrollView scrollPage() {
        ScrollView sc=new ScrollView(this); sc.setFillViewport(false); sc.setClipToPadding(false); sc.setVerticalScrollBarEnabled(false); sc.setBackgroundColor(WHITE);
        return sc;
    }
    private LinearLayout content(ScrollView sc) {
        LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(dp(21),dp(18),dp(21),dp(30)); sc.addView(c,new ScrollView.LayoutParams(-1,-2)); return c;
    }
    private TextView text(String value, float size, int color, int style) {
        TextView t=new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color); t.setTypeface(Typeface.create("sans-serif",style)); t.setIncludeFontPadding(true); t.setLineSpacing(dp(2),1f); return t;
    }
    private GradientDrawable shape(int color, int radius, int stroke) {
        GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); if(stroke!=0)d.setStroke(dp(1),stroke); return d;
    }
    private GradientDrawable outline(int color, int radius, int strokeColor, int strokeWidth) {
        GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); if(strokeColor!=0)d.setStroke(dp(strokeWidth),strokeColor); return d;
    }
    private int dp(float v) { return (int)(getResources().getDisplayMetrics().density*v+0.5f); }
    private View gap(int h) { View v=new View(this); v.setLayoutParams(new LinearLayout.LayoutParams(1,dp(h))); return v; }
    private void addGap(LinearLayout c,int h) { c.addView(gap(h)); }
    private void addText(LinearLayout p,String s,float size,int color,int style) { p.addView(text(s,size,color,style)); }
    private LinearLayout card(int padding, int background) {
        LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(dp(padding),dp(padding),dp(padding),dp(padding)); c.setBackground(shape(background,18,background==WHITE?LINE:0)); c.setElevation(dp(1)); return c;
    }
    private LinearLayout horizontal() { LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private void sectionTitle(LinearLayout c,String title,String link,Runnable action) {
        LinearLayout row=horizontal(); TextView t=text(title,19,INK,Typeface.BOLD); row.addView(t,new LinearLayout.LayoutParams(0,-2,1));
        if(link!=null){ TextView a=text(link,12,GOLD_DARK,Typeface.BOLD); row.addView(a); a.setOnClickListener(v->action.run()); }
        c.addView(row);
    }
    private void addPill(LinearLayout p,String label) {
        TextView t=text(label.toUpperCase(Locale.ROOT),10,GOLD_DARK,Typeface.BOLD); t.setLetterSpacing(0.12f); t.setPadding(dp(10),dp(7),dp(10),dp(7)); t.setBackground(shape(0xFFF0E8D8,20,0)); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,-2); lp.bottomMargin=dp(12); p.addView(t,lp);
    }
    private TextView button(String label, boolean primary) {
        TextView b=text(label,14,primary?WHITE:INK,Typeface.BOLD); b.setGravity(Gravity.CENTER); b.setPadding(dp(16),dp(14),dp(16),dp(14)); b.setMinHeight(dp(48)); b.setBackground(outline(primary?INK:WHITE,13,primary?INK:LINE,1)); b.setClickable(true); b.setFocusable(true); return b;
    }
    private void addButton(LinearLayout p,String label,boolean primary,Runnable action) { TextView b=button(label,primary); p.addView(b,new LinearLayout.LayoutParams(-1,-2)); b.setOnClickListener(v->action.run()); }
    private ImageView icon(int res,int size,int tint) { ImageView img=new ImageView(this); img.setImageResource(res); img.setColorFilter(tint); img.setScaleType(ImageView.ScaleType.FIT_CENTER); img.setLayoutParams(new LinearLayout.LayoutParams(dp(size),dp(size))); return img; }
    private void addLogoHeader(LinearLayout c) {
        LinearLayout row=horizontal();
        FrameLayout badge=new FrameLayout(this); badge.setBackground(shape(PAPER,14,0)); ImageView crown=new ImageView(this); crown.setImageResource(R.drawable.ct_crown); crown.setScaleType(ImageView.ScaleType.FIT_CENTER); FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(dp(39),dp(29),Gravity.CENTER); badge.addView(crown,cp); row.addView(badge,new LinearLayout.LayoutParams(dp(52),dp(52)));
        LinearLayout titles=new LinearLayout(this); titles.setOrientation(LinearLayout.VERTICAL); LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,-2,1); tp.leftMargin=dp(11); row.addView(titles,tp);
        TextView brand=text("CRYSTAL TALENT",17,INK,Typeface.BOLD); brand.setLetterSpacing(0.07f); titles.addView(brand);
        TextView sub=text("AWARDS  ·  TROPHIES  ·  ENGRAVING",9,MUTED,Typeface.BOLD); sub.setLetterSpacing(0.04f); LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-2,-2); sp.topMargin=dp(3); titles.addView(sub,sp);
        TextView more=text("•••",22,MUTED,Typeface.BOLD); more.setGravity(Gravity.CENTER); more.setBackground(shape(PAPER,14,0)); row.addView(more,new LinearLayout.LayoutParams(dp(42),dp(42))); more.setOnClickListener(v->openPage("about",null));
        c.addView(row);
    }
    private void addPageTitle(LinearLayout c,String eyebrow,String title,String subtitle) {
        addLogoHeader(c); addGap(c,23); addPill(c,eyebrow); addText(c,title,27,INK,Typeface.BOLD); addGap(c,7); addText(c,subtitle,14,MUTED,Typeface.NORMAL); addGap(c,22);
    }
    private ScrollView buildHome() {
        ScrollView sc=scrollPage(); LinearLayout c=content(sc); addLogoHeader(c); addGap(c,23);
        LinearLayout hero=card(20,PAPER);
        addPill(hero,"Crafted to celebrate");
        FrameLayout crownHolder=new FrameLayout(this); crownHolder.setBackground(shape(0xFFF0E8D8,30,0)); ImageView crown=new ImageView(this); crown.setImageResource(R.drawable.ct_crown); crown.setScaleType(ImageView.ScaleType.FIT_CENTER); FrameLayout.LayoutParams clp=new FrameLayout.LayoutParams(dp(72),dp(48),Gravity.CENTER); crownHolder.addView(crown,clp); LinearLayout.LayoutParams chp=new LinearLayout.LayoutParams(dp(86),dp(70)); chp.bottomMargin=dp(13); hero.addView(crownHolder,chp);
        addText(hero,"Every achievement deserves a lasting symbol.",28,INK,Typeface.BOLD); addGap(hero,10);
        addText(hero,"Thoughtfully made trophies, awards and personalised pieces for the moments that matter.",14,MUTED,Typeface.NORMAL); addGap(hero,20);
        addButton(hero,"Explore the collection  →",true,()->navigateTab("collection")); addGap(hero,9); addButton(hero,"Request a quote",false,()->{preselectedCategory="";navigateTab("quote");});
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2); c.addView(hero,hp);
        addGap(c,28); sectionTitle(c,"Explore our work","View all",()->navigateTab("collection")); addGap(c,13); addCategoryRows(c,false);
        addGap(c,22); LinearLayout service=card(18,WHITE); LinearLayout sr=horizontal(); ImageView medal=icon(R.drawable.ic_medal,44,GOLD); sr.addView(medal); LinearLayout st=new LinearLayout(this); st.setOrientation(LinearLayout.VERTICAL); LinearLayout.LayoutParams stp=new LinearLayout.LayoutParams(0,-2,1); stp.leftMargin=dp(13); sr.addView(st,stp); addText(st,"Personalised. Precise. Professional.",15,INK,Typeface.BOLD); addGap(st,4); addText(st,"Engraving, custom design and corporate gifting.",12,MUTED,Typeface.NORMAL); service.addView(sr); addGap(service,14); addButton(service,"Discover our services",false,()->openPage("service","All services")); c.addView(service);
        addGap(c,22); LinearLayout quote=card(18,INK); addPill(quote,"Start a conversation"); addText(quote,"Have an event or award in mind?",21,WHITE,Typeface.BOLD); addGap(6); addText(quote,"Share your brief. We’ll help you explore the right options.",13,0xFFD6D8D4,Typeface.NORMAL); addGap(15); addButton(quote,"Request a quote  →",true,()->{preselectedCategory="";navigateTab("quote");}); c.addView(quote);
        addGap(c,23); addFooter(c);
        return sc;
    }
    private void addCategoryRows(LinearLayout parent, boolean detailed) {
        for(int i=0;i<categories.length;i+=2) {
            LinearLayout row=horizontal(); LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2); rp.bottomMargin=dp(10); parent.addView(row,rp);
            addCategoryCard(row,categories[i],1f,detailed);
            if(i+1<categories.length) addCategoryCard(row,categories[i+1],1f,detailed);
        }
    }
    private void addCategoryCard(LinearLayout row,Category cat,float weight,boolean detailed) {
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(13),dp(14),dp(12),dp(14)); box.setBackground(shape(WHITE,16,LINE)); box.setMinimumHeight(dp(detailed?155:138));
        ImageView art=icon(cat.icon,38,GOLD); box.addView(art); addGap(box,11); addText(box,cat.title,detailed?14:13,INK,Typeface.BOLD); addGap(box,5); addText(box,cat.subtitle,11,MUTED,Typeface.NORMAL);
        box.setOnClickListener(v->openPage("category",cat.title)); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,weight); lp.leftMargin=dp(row.getChildCount()==0?0:7); lp.rightMargin=dp(3); row.addView(box,lp);
    }
    private ScrollView buildCollection() {
        ScrollView sc=scrollPage(); LinearLayout c=content(sc); addPageTitle(c,"The collection","Discover the details","Explore award and gifting categories. Choose a category to see what can be created for your event, team or organisation.");
        LinearLayout hero=card(17,PAPER); addText(hero,"Made to mark the moment.",18,INK,Typeface.BOLD); addGap(hero,6); addText(hero,"From a single custom keepsake to an event-wide recognition order, each brief starts with your needs.",13,MUTED,Typeface.NORMAL); c.addView(hero); addGap(c,20); addCategoryRows(c,true);
        addGap(c,10); LinearLayout help=card(17,0xFFF6F0E4); addText(help,"Not sure what you need?",17,INK,Typeface.BOLD); addGap(help,5); addText(help,"Tell us the occasion, quantity and budget. We can discuss suitable options with you.",13,MUTED,Typeface.NORMAL); addGap(help,14); addButton(help,"Help me choose",true,()->{preselectedCategory="Custom Awards";navigateTab("quote");}); c.addView(help); addGap(c,20); addFooter(c); return sc;
    }
    private Category findCategory(String name) { for(Category c:categories) if(c.title.equals(name))return c; return categories[5]; }
    private ScrollView buildCategory(String name) {
        Category cat=findCategory(name==null?"":name); ScrollView sc=scrollPage(); LinearLayout c=content(sc); addLogoHeader(c); addGap(c,22);
        TextView back=text("‹   BACK TO COLLECTION",11,GOLD_DARK,Typeface.BOLD); back.setLetterSpacing(0.06f); c.addView(back); back.setOnClickListener(v->{if(!history.isEmpty()){currentPage=history.remove(history.size()-1);render(currentPage,true);}else navigateTab("collection");}); addGap(c,15);
        LinearLayout feature=card(20,PAPER); ImageView art=icon(cat.icon,58,GOLD); feature.addView(art); addGap(feature,13); addPill(feature,"Crystal Talent collection"); addText(feature,cat.title,26,INK,Typeface.BOLD); addGap(feature,8); addText(feature,cat.description,14,MUTED,Typeface.NORMAL); addGap(feature,16); addButton(feature,"Request this category",true,()->{preselectedCategory=cat.title;navigateTab("quote");}); c.addView(feature);
        addGap(c,22); addText(c,"What we can discuss",18,INK,Typeface.BOLD); addGap(c,10);
        String[] items={"Custom sizes, styles and finishes","Names, logos or event-specific details","Options for individual or bulk quantities","Packaging and presentation requirements"};
        for(String item:items){LinearLayout r=horizontal(); TextView dot=text("✓",15,GOLD_DARK,Typeface.BOLD); r.addView(dot,new LinearLayout.LayoutParams(dp(25),-2)); TextView tx=text(item,13,INK,Typeface.NORMAL); r.addView(tx,new LinearLayout.LayoutParams(0,-2,1)); LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.bottomMargin=dp(12);c.addView(r,rp);}
        addGap(c,8); addText(c,"Have a reference image or logo?",17,INK,Typeface.BOLD); addGap(c,5); addText(c,"You can mention it in the request form and discuss the requirements with our team.",13,MUTED,Typeface.NORMAL); addGap(c,15); addButton(c,"Continue to quote  →",true,()->{preselectedCategory=cat.title;navigateTab("quote");}); addGap(c,22); addFooter(c); return sc;
    }
    private ScrollView buildQuote() {
        ScrollView sc=scrollPage(); LinearLayout c=content(sc); addPageTitle(c,"Tell us about your project","Request a quote","Share a few details and your request will be prepared as a WhatsApp message for our team. Nothing is submitted until you send it.");
        LinearLayout form=card(17,WHITE); addText(form,"Your details",17,INK,Typeface.BOLD); addGap(form,13);
        EditText name=field("Full name *",false,1); addFieldBlock(form,"FULL NAME",name);
        EditText org=field("Company / organisation",false,1); addFieldBlock(form,"ORGANISATION",org);
        EditText phone=field("Mobile number *",false,3); addFieldBlock(form,"PHONE NUMBER",phone);
        EditText email=field("Email (optional)",false,33); addFieldBlock(form,"EMAIL",email);
        addGap(form,3); addText(form,"WHAT ARE YOU LOOKING FOR?",10,MUTED,Typeface.BOLD); addGap(form,7);
        Spinner spinner=new Spinner(this); String[] opts={"Choose a category", "Trophies & Awards", "Mementos & Plaques", "Corporate Gifts", "2D / 3D Engraving", "Miniatures & Sculptures", "Custom Awards"}; ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,opts); spinner.setAdapter(adapter); spinner.setPadding(dp(10),dp(8),dp(10),dp(8)); spinner.setBackground(outline(WHITE,11,LINE,1)); form.addView(spinner,new LinearLayout.LayoutParams(-1,dp(50))); if(preselectedCategory!=null && !preselectedCategory.isEmpty()){for(int i=0;i<opts.length;i++)if(opts[i].equals(preselectedCategory))spinner.setSelection(i);}
        addGap(form,12); EditText qty=field("Estimated quantity",false,2); addFieldBlock(form,"QUANTITY (IF KNOWN)",qty);
        EditText date=field("Event / required-by date (optional)",false,1); addFieldBlock(form,"DATE",date);
        EditText notes=field("Describe the occasion, design, sizes, finish, logo or any other requirements…",true,1); notes.setMinHeight(dp(112)); notes.setGravity(Gravity.TOP|Gravity.START); addFieldBlock(form,"PROJECT DETAILS *",notes);
        addGap(form,5); TextView privacy=text("Your details stay in this form until you choose to continue to WhatsApp. The app does not save or upload quote requests to a server.",11,MUTED,Typeface.NORMAL); form.addView(privacy); addGap(form,15);
        addButton(form,"Continue to WhatsApp  →",true,()->{
            String n=name.getText().toString().trim(), p=phone.getText().toString().trim(), details=notes.getText().toString().trim();
            if(n.isEmpty()||p.isEmpty()||details.isEmpty()){Toast.makeText(this,"Please fill in your name, phone number and project details.",Toast.LENGTH_LONG).show();return;}
            String category=spinner.getSelectedItemPosition()==0?"Not selected":spinner.getSelectedItem().toString();
            String msg="Hello Crystal Talent, I'd like to request a quote.\n\nName: "+n+"\nOrganisation: "+org.getText().toString().trim()+"\nPhone: "+p+"\nEmail: "+email.getText().toString().trim()+"\nCategory: "+category+"\nQuantity: "+qty.getText().toString().trim()+"\nRequired by: "+date.getText().toString().trim()+"\nProject details: "+details;
            try { String encoded=URLEncoder.encode(msg,"UTF-8"); startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/91"+PHONE_NAIM+"?text="+encoded))); }
            catch(Exception ex){Toast.makeText(this,"Unable to open WhatsApp right now. Please contact us by phone.",Toast.LENGTH_LONG).show();}
        }); c.addView(form); addGap(c,20); addFooter(c); return sc;
    }
    private EditText field(String hint,boolean multiline,int inputType) {
        EditText e=new EditText(this); e.setHint(hint); e.setTextSize(14); e.setTextColor(INK); e.setHintTextColor(0xFF9A9D97); e.setSingleLine(!multiline); e.setInputType(inputType==1?android.text.InputType.TYPE_CLASS_TEXT:inputType==2?android.text.InputType.TYPE_CLASS_NUMBER:inputType==3?android.text.InputType.TYPE_CLASS_PHONE:inputType==33?android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS|android.text.InputType.TYPE_CLASS_TEXT:android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE); e.setPadding(dp(12),dp(10),dp(12),dp(10)); e.setBackground(outline(WHITE,11,LINE,1)); return e;
    }
    private void addFieldBlock(LinearLayout parent,String label,EditText field) { addGap(parent,7); addText(parent,label,10,MUTED,Typeface.BOLD); addGap(parent,5); parent.addView(field,new LinearLayout.LayoutParams(-1,field.getMinHeight()>dp(60)?dp(112):dp(49))); }
    private ScrollView buildContact() {
        ScrollView sc=scrollPage(); LinearLayout c=content(sc); addPageTitle(c,"We’re here to help","Get in touch","Discuss an award idea, request a quote or ask about a custom order. Our team can help you explore the next step.");
        LinearLayout primary=card(18,PAPER); addPill(primary,"Contact our team"); addText(primary,"Naim Khan",17,INK,Typeface.BOLD); addGap(primary,4); addText(primary,PHONE_NAIM,14,MUTED,Typeface.NORMAL); addGap(primary,12); addButton(primary,"Call Naim Khan",true,()->dial(PHONE_NAIM)); addGap(primary,9); addText(primary,"Amaan  ·  "+PHONE_AMAN,13,MUTED,Typeface.NORMAL); addGap(primary,9); addButton(primary,"Call Aman",false,()->dial(PHONE_AMAN)); c.addView(primary);
        addGap(c,13); LinearLayout address=card(17,WHITE); LinearLayout rr=horizontal(); rr.addView(icon(R.drawable.ic_pin,30,GOLD)); LinearLayout at=new LinearLayout(this); at.setOrientation(LinearLayout.VERTICAL); LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(0,-2,1);ap.leftMargin=dp(12);rr.addView(at,ap); addText(at,"Visit our store",16,INK,Typeface.BOLD); addGap(at,5); addText(at,"Dharavi T Junction · Shop No. 17 DHGN · 1st Floor · Sion–Mahim Link Road, Dharavi, Mumbai",13,MUTED,Typeface.NORMAL); address.addView(rr); addGap(address,14); addButton(address,"Open in Maps  ↗",false,()->{try{String q=URLEncoder.encode("Crystal Talent, Shop No. 17 DHGN, Sion Mahim Link Road, Dharavi, Mumbai","UTF-8");startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("geo:0,0?q="+q)));}catch(Exception e){}}); c.addView(address);
        addGap(c,13); LinearLayout web=card(17,WHITE); LinearLayout wr=horizontal(); wr.addView(icon(R.drawable.ic_web,30,GOLD)); LinearLayout wt=new LinearLayout(this); wt.setOrientation(LinearLayout.VERTICAL); LinearLayout.LayoutParams wtp=new LinearLayout.LayoutParams(0,-2,1);wtp.leftMargin=dp(12);wr.addView(wt,wtp); addText(wt,"Website",16,INK,Typeface.BOLD); addGap(wt,4); addText(wt,"www.crystaltalent.com",13,MUTED,Typeface.NORMAL); web.addView(wr); addGap(web,13); addButton(web,"Visit website  ↗",false,()->openUrl("https://crystaltalent.com")); c.addView(web);
        addGap(c,20); addText(c,"Prefer to explain your idea first?",17,INK,Typeface.BOLD); addGap(c,6); addText(c,"Send us a message with the occasion, approximate quantity and any references you have.",13,MUTED,Typeface.NORMAL); addGap(c,14); addButton(c,"Start a quote request",true,()->{preselectedCategory="";navigateTab("quote");}); addGap(c,22); addFooter(c); return sc;
    }
    private ScrollView buildAbout() {
        ScrollView sc=scrollPage(); LinearLayout c=content(sc); addPageTitle(c,"The Crystal Talent approach","Recognition, made personal.","We help turn achievements, milestones and special occasions into tangible keepsakes.");
        LinearLayout brand=card(20,PAPER); FrameLayout logo=new FrameLayout(this); logo.setBackground(shape(0xFFF0E8D8,25,0)); ImageView cr=new ImageView(this);cr.setImageResource(R.drawable.ct_crown);FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(dp(77),dp(52),Gravity.CENTER);logo.addView(cr,cp);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(92),dp(82));lp.bottomMargin=dp(14);brand.addView(logo,lp); addText(brand,"Crystal Talent",24,INK,Typeface.BOLD); addGap(brand,8); addText(brand,"Trophies · awards · plaques · corporate gifts · engraving",13,MUTED,Typeface.NORMAL); addGap(brand,12); addText(brand,"A professional, collaborative approach—from understanding the occasion to discussing the right style, personalisation and finish.",14,INK,Typeface.NORMAL); c.addView(brand);
        addGap(c,22); addText(c,"What matters to us",18,INK,Typeface.BOLD); addGap(c,12);
        String[][] values={{"01","A clear brief","Understanding your event, recipient, quantity and preferred look."},{"02","Thoughtful detail","Personalisation and finishing choices that support the message you want to make."},{"03","A smooth process","Practical communication about design options, timelines and order requirements."}};
        for(String[] v:values){LinearLayout row=card(15,WHITE);LinearLayout h=horizontal();TextView n=text(v[0],15,GOLD_DARK,Typeface.BOLD);n.setGravity(Gravity.CENTER);n.setBackground(shape(0xFFF0E8D8,12,0));h.addView(n,new LinearLayout.LayoutParams(dp(42),dp(42)));LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,-2,1);bp.leftMargin=dp(12);h.addView(body,bp);addText(body,v[1],15,INK,Typeface.BOLD);addGap(body,4);addText(body,v[2],12,MUTED,Typeface.NORMAL);row.addView(h);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.bottomMargin=dp(10);c.addView(row,rp);}
        addGap(c,8); addButton(c,"Explore our collection",true,()->navigateTab("collection")); addGap(c,9); addButton(c,"Contact the team",false,()->navigateTab("contact")); addGap(c,22); addFooter(c); return sc;
    }
    private ScrollView buildPortfolio() {
        ScrollView sc=scrollPage(); LinearLayout c=content(sc); addPageTitle(c,"A world of possibilities","Ideas for every occasion","Browse sample directions for events, recognition programmes, business milestones and personalised gifts.");
        String[][] ideas={{"Annual awards","Trophies and presentation pieces for recognition events.","Trophies & Awards", "trophy"},{"Appreciation & milestones","Mementos to mark years of service, partnerships and achievements.","Mementos & Plaques","plaque"},{"Brand-led gifting","Corporate keepsakes personalised to suit your message.","Corporate Gifts","gift"},{"Personalised details","Names, logos and messages finished with precision.","2D / 3D Engraving","laser"}};
        int[] ids={R.drawable.ic_trophy,R.drawable.ic_plaque,R.drawable.ic_gift,R.drawable.ic_laser};
        for(int i=0;i<ideas.length;i++){final String cat=ideas[i][2];LinearLayout box=card(16,WHITE);LinearLayout r=horizontal();FrameLayout artbg=new FrameLayout(this);artbg.setBackground(shape(PAPER,16,0));ImageView img=new ImageView(this);img.setImageResource(ids[i]);img.setColorFilter(GOLD);artbg.addView(img,new FrameLayout.LayoutParams(dp(47),dp(47),Gravity.CENTER));r.addView(artbg,new LinearLayout.LayoutParams(dp(72),dp(72)));LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,-2,1);bp.leftMargin=dp(13);r.addView(body,bp);addText(body,ideas[i][0],16,INK,Typeface.BOLD);addGap(body,5);addText(body,ideas[i][1],12,MUTED,Typeface.NORMAL);box.addView(r);addGap(box,13);TextView open=text("Explore this category  →",12,GOLD_DARK,Typeface.BOLD);box.addView(open);box.setOnClickListener(v->openPage("category",cat));LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.bottomMargin=dp(12);c.addView(box,rp);}
        addGap(c,4); addText(c,"Have a reference or a specific concept?",17,INK,Typeface.BOLD); addGap(c,6); addText(c,"Let us know what you are picturing, and we can discuss the possibilities with you.",13,MUTED,Typeface.NORMAL); addGap(c,14); addButton(c,"Share your idea",true,()->{preselectedCategory="";navigateTab("quote");}); addGap(c,22); addFooter(c); return sc;
    }
    private ScrollView buildService(String serviceName) {
        ScrollView sc=scrollPage(); LinearLayout c=content(sc); addPageTitle(c,"Services","A considered finish","A range of award, gifting and personalisation options, discussed around your brief.");
        String[][] services={{"Custom awards & trophies","Explore sizes, shapes, materials and finishes suitable for your ceremony or recognition programme.","Trophies & Awards"},{"Laser engraving","Discuss adding names, logos, dates or messages to suitable pieces and materials.","2D / 3D Engraving"},{"Corporate & event gifting","Consider coordinated gifts or presentation pieces for teams, clients and guests.","Corporate Gifts"},{"Plaques & mementos","Create a commemorative piece for a milestone, partnership, honour or event.","Mementos & Plaques"}};
        int[] ids={R.drawable.ic_trophy,R.drawable.ic_laser,R.drawable.ic_gift,R.drawable.ic_plaque};
        for(int i=0;i<services.length;i++){final String cat=services[i][2];LinearLayout box=card(17,WHITE);box.addView(icon(ids[i],40,GOLD));addGap(box,11);addText(box,services[i][0],17,INK,Typeface.BOLD);addGap(box,5);addText(box,services[i][1],13,MUTED,Typeface.NORMAL);addGap(box,13);TextView act=text("Discuss this service  →",12,GOLD_DARK,Typeface.BOLD);box.addView(act);box.setOnClickListener(v->{preselectedCategory=cat;navigateTab("quote");});LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.bottomMargin=dp(12);c.addView(box,rp);}
        addGap(c,4);addButton(c,"Request a custom quote",true,()->{preselectedCategory="";navigateTab("quote");});addGap(c,22);addFooter(c);return sc;
    }
    private void addFooter(LinearLayout c) {
        View line=new View(this);line.setBackgroundColor(LINE);c.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));addGap(c,14);
        LinearLayout r=horizontal();ImageView crown=icon(R.drawable.ct_crown,34,GOLD);r.addView(crown);LinearLayout tx=new LinearLayout(this);tx.setOrientation(LinearLayout.VERTICAL);LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,-2,1);tp.leftMargin=dp(9);r.addView(tx,tp);addText(tx,"CRYSTAL TALENT",12,INK,Typeface.BOLD);addGap(tx,3);addText(tx,"Made to mark the moment.",11,MUTED,Typeface.NORMAL);c.addView(r);addGap(c,10);addText(c,"Dharavi · Mumbai, Maharashtra",11,MUTED,Typeface.NORMAL);
    }
    private void dial(String phone) { try{startActivity(new Intent(Intent.ACTION_DIAL,Uri.parse("tel:"+phone)));}catch(Exception e){Toast.makeText(this,phone,Toast.LENGTH_LONG).show();} }
    private void openUrl(String url) { try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception e){Toast.makeText(this,"Unable to open the link right now.",Toast.LENGTH_SHORT).show();} }
    @Override public void onBackPressed() {
        if(!history.isEmpty()){currentPage=history.remove(history.size()-1);render(currentPage,true);}
        else if(!currentPage.type.equals("home")){navigateTab("home");}
        else super.onBackPressed();
    }
}
